Mido AI HTML
============

هذه نسخة HTML/CSS/JS مخصصة لتغليفها كتطبيق Android.

الملفات:
- index.html
- style.css
- app.js

مهم:
1) افتح app.js.
2) غيّر BACKEND_URL إلى رابط الـBackend الحقيقي.
3) لا تضع مفتاح OpenAI داخل app.js أو أي ملف Frontend.
4) بعد ذلك ارفع المجلد إلى خدمة تحويل Website/HTML إلى APK.

الواجهة جاهزة لتتصل بهذه المسارات:
POST /api/auth/request-code
POST /api/auth/verify-code
POST /api/chat

ويدعم الـFrontend token في localStorage.
