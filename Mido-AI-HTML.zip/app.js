// غيّر هذا العنوان بعد نشر الـBackend
const BACKEND_URL = "https://YOUR-BACKEND-DOMAIN.example";
let token = localStorage.getItem("mido_token") || "";
let conversationId = null;

const $=id=>document.getElementById(id);
function show(id){document.querySelectorAll(".screen").forEach(x=>x.classList.add("hidden"));$(id).classList.remove("hidden")}
function error(id,msg){$(id).textContent=msg}
function addMessage(text,type){const d=document.createElement("div");d.className="msg "+type;d.textContent=text;$("messages").appendChild(d);$("messages").scrollTop=$("messages").scrollHeight}
async function api(path,options={}){
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(token) headers.Authorization="Bearer "+token;
  const r=await fetch(BACKEND_URL+path,{...options,headers});
  if(!r.ok) throw new Error((await r.text())||"Request failed");
  return r.json();
}

$("sendCode").onclick=async()=>{
  const email=$("email").value.trim();
  if(!email) return error("loginError","اكتب البريد الإلكتروني");
  try{await api("/api/auth/request-code",{method:"POST",body:JSON.stringify({email})});show("otp");error("loginError","")}
  catch(e){error("loginError","تعذر إرسال الكود. تأكد من تشغيل الـBackend.")}
};

$("verify").onclick=async()=>{
  const code=$("otpCode").value.trim(),email=$("email").value.trim();
  if(code.length!==6)return error("otpError","الكود يجب أن يكون 6 أرقام");
  try{
    const r=await api("/api/auth/verify-code",{method:"POST",body:JSON.stringify({email,code})});
    token=r.token;localStorage.setItem("mido_token",token);$("plan").textContent=r.user?.status==="plus"?"Mido Plus":"Free";show("chat");
  }catch(e){error("otpError","الكود غير صحيح أو انتهت صلاحيته")}
};

$("chatForm").onsubmit=async e=>{
  e.preventDefault();const input=$("message"),text=input.value.trim();if(!text)return;
  input.value="";addMessage(text,"user");
  try{
    const r=await api("/api/chat",{method:"POST",body:JSON.stringify({message:text,conversationId})});
    conversationId=r.conversationId||conversationId;
    addMessage(r.answer||"لم يصل رد من النموذج.","ai");
    if(r.remaining!==undefined && r.remaining!==null)$("plan").textContent=(r.remaining+" رسالة متبقية");
  }catch(e){addMessage("حدث خطأ في الاتصال بالذكاء الاصطناعي.","ai")}
};

$("logout").onclick=()=>{token="";localStorage.removeItem("mido_token");conversationId=null;show("login")};

if(token)show("chat");else show("login");
