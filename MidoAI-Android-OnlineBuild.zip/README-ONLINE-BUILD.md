# Mido AI — أسهل طريقة لإخراج APK أونلاين

النسخة دي مجهزة بـ GitHub Actions، لذلك لا تحتاج Android Studio على جهازك.

## الطريقة
1. أنشئ حساب GitHub.
2. أنشئ Repository جديد باسم `mido-ai`.
3. ارفع كل ملفات هذا المشروع كما هي إلى الـRepository.
4. افتح تبويب `Actions`.
5. اختر `Build Mido AI APK`.
6. اضغط `Run workflow`.
7. بعد انتهاء البناء افتح نتيجة الـWorkflow.
8. من قسم `Artifacts` نزّل `MidoAI-debug-apk`.
9. فك ZIP وستجد `app-debug.apk`.

## قبل التشغيل
في `MainActivity.kt` غيّر:
`BACKEND_URL`
إلى رابط Backend الحقيقي، وليس `10.0.2.2`، لأن هذا العنوان خاص بالمحاكي فقط.

## مهم
- مفتاح OpenAI لا يوضع في التطبيق.
- التطبيق يحتاج Backend منشور على الإنترنت.
- الـAPK الناتج Debug للتجربة. للنشر على Google Play تحتاج Release APK/AAB وتوقيعًا خاصًا.
