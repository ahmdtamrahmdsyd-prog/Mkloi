package com.midoai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import io.socket.client.IO
import io.socket.client.Socket
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST

private const val BACKEND_URL = "http://10.0.2.2:8080/"

data class User(val id:String="",val email:String="",val language:String="ar",val status:String="free")
data class AuthResponse(val token:String,val user:User)
data class Basic(val ok:Boolean=true)
data class ChatResponse(val conversationId:String,val answer:String,val remaining:Int?,val status:String)
data class ChatRequest(val message:String,val conversationId:String?)

interface Api {
    @POST("api/auth/request-code") suspend fun requestCode(@Body body:Map<String,String>):Basic
    @POST("api/auth/verify-code") suspend fun verify(@Body body:Map<String,String>):AuthResponse
    @POST("api/chat") suspend fun chat(@Header("Authorization") auth:String,@Body body:ChatRequest):ChatResponse
}

class MainActivity:ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent { MidoAIApp() }
    }
}

@Composable
fun MidoAIApp(){
    val scope=rememberCoroutineScope()
    val api=remember {
        Retrofit.Builder().baseUrl(BACKEND_URL)
            .addConverterFactory(GsonConverterFactory.create()).build()
            .create(Api::class.java)
    }
    var screen by remember { mutableStateOf("login") }
    var email by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    MaterialTheme(colorScheme=darkColorScheme(primary=Color(0xFF8E1830),background=Color(0xFF100608),surface=Color(0xFF1B0A0E))){
        when(screen){
            "login" -> LoginScreen(email,{email=it},{
                scope.launch(Dispatchers.Main){
                    try { api.requestCode(mapOf("email" to email)); screen="otp"; error="" }
                    catch(e:Exception){ error=e.message ?: "حدث خطأ" }
                }
            },error)
            "otp" -> OtpScreen(otp,{otp=it},{
                scope.launch(Dispatchers.Main){
                    try {
                        val r=api.verify(mapOf("email" to email,"code" to otp))
                        token=r.token; screen="chat"; error=""
                    } catch(e:Exception){ error=e.message ?: "الكود غير صحيح" }
                }
            },error)
            else -> ChatScreen(api,token)
        }
    }
}

@Composable
fun LoginScreen(email:String,onEmail:(String)->Unit,send:()->Unit,error:String){
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
        Text("Mido AI",style=MaterialTheme.typography.headlineLarge)
        Text("تسجيل الدخول بالبريد الإلكتروني")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(value=email,onValueChange=onEmail,label={Text("البريد الإلكتروني")},singleLine=true)
        Spacer(Modifier.height(12.dp))
        Button(onClick=send,modifier=Modifier.fillMaxWidth()){Text("إرسال كود التحقق")}
        if(error.isNotEmpty()){Spacer(Modifier.height(12.dp));Text(error,color=Color(0xFFFF9EAE))}
    }
}

@Composable
fun OtpScreen(otp:String,onOtp:(String)->Unit,verify:()->Unit,error:String){
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
        Text("Mido AI",style=MaterialTheme.typography.headlineLarge)
        Text("أدخل كود التحقق المكوّن من 6 أرقام")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(value=otp,onValueChange={if(it.length<=6)onOtp(it)},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
        Spacer(Modifier.height(12.dp))
        Button(onClick=verify,modifier=Modifier.fillMaxWidth()){Text("دخول")}
        if(error.isNotEmpty())Text(error,color=Color(0xFFFF9EAE))
    }
}

@Composable
fun ChatScreen(api:Api,token:String){
    val scope=rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf<Pair<Boolean,String>>()) }
    var cid by remember { mutableStateOf<String?>(null) }
    var notice by remember { mutableStateOf("") }

    DisposableEffect(token){
        val socket:Socket=IO.socket(BACKEND_URL)
        socket.on(Socket.EVENT_CONNECT){socket.emit("auth:user",JSONObject().put("token",token))}
        socket.on("user:update"){args ->
            val o=args.firstOrNull() as? JSONObject
            if(o?.optString("status")=="plus") notice="تم تفعيل Mido Plus فورًا ⭐"
        }
        socket.on("force:logout"){notice="تم حظرك/تسجيل خروجك من السيرفر."}
        socket.on("maintenance:update"){args ->
            val o=args.firstOrNull() as? JSONObject
            if(o?.optBoolean("enabled")==true) notice="Mido AI في وضع الصيانة."
            else notice=""
        }
        socket.connect()
        onDispose{socket.disconnect();socket.off()}
    }

    Column(Modifier.fillMaxSize()){
        Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){
            Text("Mido AI",style=MaterialTheme.typography.titleLarge)
            Text("Free / Plus")
        }
        if(notice.isNotEmpty()) Text(notice,Modifier.fillMaxWidth().padding(12.dp),color=Color(0xFFFF9EAE))
        LazyColumn(Modifier.weight(1f).padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(messages){m ->
                Box(Modifier.fillMaxWidth(),contentAlignment=if(m.first)Alignment.CenterEnd else Alignment.CenterStart){
                    Text(m.second,Modifier.background(if(m.first)Color(0xFF7C152B) else Color(0xFF271117),RoundedCornerShape(16.dp)).padding(14.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp),verticalAlignment=Alignment.CenterVertically){
            OutlinedTextField(value=text,onValueChange={text=it},modifier=Modifier.weight(1f),placeholder={Text("اكتب رسالتك...")})
            Spacer(Modifier.width(8.dp))
            Button(onClick={
                val t=text.trim(); if(t.isEmpty()) return@Button
                text=""; messages=messages + (true to t)
                scope.launch(Dispatchers.Main){
                    try {
                        val r=api.chat("Bearer $token",ChatRequest(t,cid))
                        cid=r.conversationId
                        messages=messages + (false to r.answer)
                    } catch(e:Exception) {
                        messages=messages + (false to ("حدث خطأ: "+(e.message ?: "خطأ")))
                    }
                }
            }){Text("إرسال")}
        }
    }
}
